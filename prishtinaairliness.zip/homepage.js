document.querySelector(".search-btn").onclick = (e) => {
    alert("Searching flights...");
};

function showMessage() {
  alert("This feature will be available soon!");
}

function openJetForm() {
  alert("Private jet request received. Our team will contact you shortly.");
}


